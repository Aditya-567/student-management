import { Component, EventEmitter, Output } from '@angular/core';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  username = '';
  password = '';
  errorMessage = '';

  @Output() loginSuccess = new EventEmitter<void>();

  constructor(private toastr: ToastrService) {} // inject ToastrService

  login(): void {
    if (this.username === 'admin' && this.password === 'admin') {
      localStorage.setItem('isLoggedIn', 'true');
      this.loginSuccess.emit();
    } else {
      this.toastr.error('invalid username or password', 'Login Failed');
    }
  }
}
