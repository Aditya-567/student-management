import { Component, signal } from '@angular/core';
import { Student } from '../student.model';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css'],
})
export class StudentListComponent {
  students = signal<Student[]>([]);
  selectedStudent = signal<Student | null>(null);

  constructor(private studentService: StudentService) {
    this.loadStudents();
  }

  loadStudents() {
    this.students.set([...this.studentService.getStudents()]);
  }

  selectStudent(student: Student): void {
    this.selectedStudent.set(student);
  }

  addStudent(newStudent: Student): void {
    this.studentService.addStudent(newStudent);
    this.students.set([...this.studentService.getStudents()]);
  }
}
