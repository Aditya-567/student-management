import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';

  handleLoginSuccess(): void {
    this.isLoggedIn = true;
    localStorage.setItem('isLoggedIn', 'true');
  }

  handleLogout(): void {
    localStorage.removeItem('isLoggedIn');
    this.isLoggedIn = false;
  }
}
