import {
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  Output,
  signal,
} from '@angular/core';
import { Student } from '../student.model';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-details',
  templateUrl: './student-details.component.html',
  styleUrls: ['./student-details.component.css'],
})
export class StudentDetailsComponent implements OnDestroy {
  @Input() selectedStudent!: Student | null;
  @Output() studentRemoved = new EventEmitter<string>();

  // selectedStudent = input<Student | null>();
  // studentRemoved = output<string>();

  isUpdateModalOpen = signal(false);
  studentToUpdate = signal<Student | null>(null);

  constructor(private studentService: StudentService) {}

  removeStudent(): void {
    if (this.selectedStudent) {
      console.log(`Removing student: ${this.selectedStudent.name}`);
      this.studentRemoved.emit(this.selectedStudent.id);
      this.ngOnDestroy(); // Calls `ngOnDestroy()` only when a student is removed
    }
  }

  openUpdateModal(): void {
    if (this.selectedStudent) {
      this.studentToUpdate.set({ ...this.selectedStudent }); // Clone student object
      this.isUpdateModalOpen.set(true);
    }
  }

  closeUpdateModal(): void {
    this.isUpdateModalOpen.set(false);
  }

  updateStudent(updatedStudent: Student): void {
    this.studentService.updateStudent(updatedStudent);
    this.selectedStudent = updatedStudent; // Update displayed data
    this.isUpdateModalOpen.set(false);
  }

  // Lifecycle method that runs ONLY when a student is removed
  ngOnDestroy(): void {
    console.log(
      'StudentDetailsComponent is being destroyed due to student removal.'
    );
  }
}
