import { Component, input } from '@angular/core';
import { Student } from '../student.model';

@Component({
  selector: 'app-student-details',
  templateUrl: './student-details.component.html',
  styleUrls: ['./student-details.component.css'],
})
export class StudentDetailsComponent {
  // @Input() selectedStudent!: Student | null;
  selectedStudent = input<Student | null>(null);
}
