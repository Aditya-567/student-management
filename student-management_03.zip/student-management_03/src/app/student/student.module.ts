import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { StudentAddComponent } from './student-add/student-add.component';
import { StudentDetailsComponent } from './student-details/student-details.component';
import { StudentListComponent } from './student-list/student-list.component';
import { StudentUpdateComponent } from './student-update/student-update.component';

@NgModule({
  declarations: [
    StudentListComponent,
    StudentDetailsComponent,
    StudentAddComponent,
    StudentUpdateComponent,
  ],
  imports: [CommonModule, FormsModule],
  exports: [
    StudentListComponent,
    StudentDetailsComponent,
    StudentAddComponent,
    StudentUpdateComponent,
  ],
})
export class StudentModule {}
