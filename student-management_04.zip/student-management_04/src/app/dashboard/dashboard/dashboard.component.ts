import { Component, OnInit, computed } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../auth/auth.service';
import { Student } from '../../student/student.model';
import { StudentService } from '../../student/student.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  // Computed signals to track login state dynamically
  isLoggedInSignal = computed(() => this.authService.isLoggedIn());
  userRoleSignal = computed(() => this.authService.getUserRole());

  constructor(
    private authService: AuthService,
    private studentService: StudentService,
    private router: Router
  ) {}

  ngOnInit(): void {
    // No need to manually set signals, computed() will react to changes
  }

  handleLoginSuccess(): void {
    setTimeout(() => {
      this.isLoggedInSignal(); //  Force reactivity update
      this.userRoleSignal(); //  Ensure role updates

      const updatedRole = this.userRoleSignal();
      if (updatedRole === 'admin') {
        this.router.navigate(['/students']);
      } else if (updatedRole === 'user') {
        this.router.navigate(['/user']);
      }
    }, 100);
  }

  handleLogout(): void {
    this.authService.logout();
    this.isLoggedInSignal(); //  Ensure logout triggers UI update
    this.router.navigate(['/']);
  }

  handleAddStudent(student: Student): void {
    this.studentService.addStudent(student);
    console.log('Student added in dashboard component', student);
  }
}
