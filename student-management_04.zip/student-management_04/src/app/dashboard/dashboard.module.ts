import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CoreModule } from '../core/core.module';
import { StudentModule } from '../student/student.module';
import { UserModule } from '../user/user.module';
import { DashboardRouteModule } from './dashboard-routes.module';
import { DashboardComponent } from './dashboard/dashboard.component';

@NgModule({
  declarations: [DashboardComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DashboardRouteModule,
    CoreModule,
    StudentModule,
    UserModule,
  ],
  exports: [DashboardComponent],
})
export class DashboardModule {}
