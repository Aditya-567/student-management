import { Injectable } from '@angular/core';
import { Student } from './student.model';

@Injectable({
  providedIn: 'root',
})
export class StudentService {
  private students: Student[] = [
    {
      id: 'U1A9B',
      name: 'Aarav Mehta',
      age: 21,
      address: 'Delhi, India',
      branch: 'Computer Science',
      cgpa: 8.5,
      result: 'Pass',
      projects: [
        'AI-based Chatbot',
        'Face Recognition System',
        'Sentiment Analysis Tool',
      ],
      hobbies: ['Coding', 'Gaming', 'Reading'],
    },
    {
      id: 'X5P7Q',
      name: 'Ishita Sharma',
      age: 22,
      address: 'Mumbai, India',
      branch: 'Information Technology',
      cgpa: 8.9,
      result: 'Pass',
      projects: [
        'Blockchain Voting System',
        'Decentralized File Storage',
        'AI-Powered Resume Builder',
      ],
      hobbies: ['Sketching', 'Photography', 'Blogging'],
    },
    {
      id: 'M3Z2K',
      name: 'Rohan Deshmukh',
      age: 20,
      address: 'Pune, India',
      branch: 'Mechanical Engineering',
      cgpa: 7.8,
      result: 'Pass',
      projects: [
        'Electric Go-Kart',
        '3D Printed Prosthetic Arm',
        'Autonomous Drone',
      ],
      hobbies: ['Football', 'Robotics', 'Traveling'],
    },
    {
      id: 'Y9X6V',
      name: 'Sneha Nair',
      age: 21,
      address: 'Bangalore, India',
      branch: 'Electronics and Communication',
      cgpa: 8.2,
      result: 'Pass',
      projects: [
        'IoT Smart Home System',
        'Gesture-Controlled Robot',
        'Wireless Energy Transfer System',
      ],
      hobbies: ['Dancing', 'Chess', 'Podcasting'],
    },
    {
      id: 'A7Q3J',
      name: 'Vikram Singh',
      age: 23,
      address: 'Chandigarh, India',
      branch: 'Civil Engineering',
      cgpa: 7.5,
      result: 'Pass',
      projects: [
        'Eco-Friendly Concrete',
        'Automated Traffic Management',
        'Bridge Structural Analysis',
      ],
      hobbies: ['Cricket', 'Photography', 'Cycling'],
    },
    {
      id: 'W4M8T',
      name: 'Pooja Patel',
      age: 22,
      address: 'Ahmedabad, India',
      branch: 'Biotechnology',
      cgpa: 9.0,
      result: 'Pass',
      projects: [
        'DNA Sequencing Tool',
        'Genetic Algorithm for Disease Prediction',
        'Biofuel Production',
      ],
      hobbies: ['Reading', 'Painting', 'Yoga'],
    },
    {
      id: 'Z2N5X',
      name: 'Rahul Gupta',
      age: 20,
      address: 'Kolkata, India',
      branch: 'Artificial Intelligence',
      cgpa: 8.7,
      result: 'Pass',
      projects: [
        'Self-Driving Car Simulation',
        'AI for Medical Diagnosis',
        'Real-time Object Detection',
      ],
      hobbies: ['Gaming', 'AI Research', 'Music'],
    },
    {
      id: 'T8B6R',
      name: 'Meera Krishnan',
      age: 21,
      address: 'Chennai, India',
      branch: 'Chemical Engineering',
      cgpa: 7.9,
      result: 'Pass',
      projects: [
        'Water Purification System',
        'Eco-friendly Plastic',
        'Bio-waste Management',
      ],
      hobbies: ['Cooking', 'Volunteering', 'Singing'],
    },
    {
      id: 'K5X3Y',
      name: 'Siddharth Verma',
      age: 22,
      address: 'Jaipur, India',
      branch: 'Data Science',
      cgpa: 8.6,
      result: 'Pass',
      projects: [
        'Predictive Analytics for Stocks',
        'Fraud Detection System',
        'Data Visualization Dashboard',
      ],
      hobbies: ['Table Tennis', 'Coding', 'Traveling'],
    },
  ];

  getStudents(): Student[] {
    return this.students;
  }

  addStudent(student: Student): void {
    this.students.push(student);
    console.log('Student added here ', student);
  }

  removeStudent(studentId: string): void {
    this.students = this.students.filter((student) => student.id !== studentId);
    console.log('Student removed:', studentId);
  }

  updateStudent(updatedStudent: Student): void {
    const index = this.students.findIndex(
      (student) => student.id === updatedStudent.id
    );
    if (index !== -1) {
      this.students[index] = updatedStudent;
      console.log('Student updated:', updatedStudent);
    }
  }
}
