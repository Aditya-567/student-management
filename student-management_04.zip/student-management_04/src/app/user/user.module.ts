import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { UserRouteModule } from './user-routes.module';
import { UserComponent } from './user.component';

@NgModule({
  declarations: [UserComponent],
  imports: [CommonModule, UserRouteModule],
  exports: [UserComponent],
})
export class UserModule {}
