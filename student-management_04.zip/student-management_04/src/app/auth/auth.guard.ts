import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  Router,
  RouterStateSnapshot,
} from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean {
    const isLoggedIn = this.authService.isLoggedIn();
    const expectedRole = route.data['role']; // Expected role from route
    const userRole = this.authService.getUserRole(); // Get user role from auth service

    if (!isLoggedIn) {
      // Redirect to login if not authenticated
      this.router.navigate(['/login']);
      return false;
    }

    if (expectedRole && expectedRole !== userRole) {
      //  Redirect unauthorized users to dashboard if role doesn't match
      this.router.navigate(['/login']);
      return false;
    }

    return true; // Allow access if authenticated and role matches
  }
}
