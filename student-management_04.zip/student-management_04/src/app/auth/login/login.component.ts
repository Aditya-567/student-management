import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  username = '';
  password = '';

  constructor(
    private authService: AuthService,
    private toastr: ToastrService,
    private router: Router
  ) {}

  login(): void {
    const role = this.authService.login(this.username, this.password);

    if (role) {
      this.toastr.success(`Welcome, ${role}!`, 'Login Successful');

      // Directly navigate based on the updated role
      const updatedRole = this.authService.getUserRole(); // Get updated role immediately after login
      if (updatedRole === 'admin') {
        this.router.navigate(['/students']);
      } else if (updatedRole === 'user') {
        this.router.navigate(['/user']);
      }
    } else {
      this.toastr.error('Invalid username or password', 'Login Failed');
    }
  }

  goToSignUp() {
    this.router.navigate(['/sign-up']);
  }
}
