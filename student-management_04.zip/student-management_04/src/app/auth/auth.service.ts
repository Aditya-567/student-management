import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  // Make signals public so other components can observe changes
  isLoggedInSignal = signal<boolean>(this.getLoginStatus());
  userRoleSignal = signal<string | null>(this.loadUserRole());

  private getLoginStatus(): boolean {
    return localStorage.getItem('isLoggedIn') === 'true';
  }

  private loadUserRole(): string | null {
    return localStorage.getItem('userRole');
  }

  isLoggedIn() {
    return this.isLoggedInSignal();
  }

  getUserRole() {
    return this.userRoleSignal();
  }

  login(username: string, password: string): string | null {
    if (username === 'admin' && password === 'admin') {
      localStorage.setItem('isLoggedIn', 'true');
      localStorage.setItem('userRole', 'admin');
      this.isLoggedInSignal.set(true);
      this.userRoleSignal.set('admin');
      return 'admin';
    } else if (username === 'user' && password === 'user') {
      localStorage.setItem('isLoggedIn', 'true');
      localStorage.setItem('userRole', 'user');
      this.isLoggedInSignal.set(true);
      this.userRoleSignal.set('user');
      return 'user';
    } else {
      return null;
    }
  }

  logout(): void {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('userRole');
    this.isLoggedInSignal.set(false);
    this.userRoleSignal.set(null);
  }
}
