import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; //  Required for Toastr
import { ToastrModule } from 'ngx-toastr';
import { AuthRouteModule } from './auth-route.module';
import { LoginComponent } from './login/login.component';
import { SignUpComponent } from './sign-up/sign-up.component';

@NgModule({
  declarations: [LoginComponent, SignUpComponent],
  imports: [
    CommonModule,
    FormsModule,
    AuthRouteModule,
    ReactiveFormsModule,
    BrowserAnimationsModule, //  Ensure animations are enabled
    ToastrModule.forRoot({
      positionClass: 'toast-top-right',
      timeOut: 3000,
      closeButton: true,
      progressBar: true,
    }),
  ],
  exports: [LoginComponent, SignUpComponent],
})
export class AuthModule {}
