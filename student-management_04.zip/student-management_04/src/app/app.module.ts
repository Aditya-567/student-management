import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routes.module';
import { AuthModule } from './auth/auth.module';
import { CoreModule } from './core/core.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { StudentModule } from './student/student.module';
import { UserModule } from './user/user.module';

@NgModule({
  declarations: [AppComponent], // Only AppComponent should be declared here
  imports: [
    BrowserModule,
    CoreModule,
    AuthModule,
    StudentModule,
    RouterModule,
    AppRoutingModule, //  AppRoutingModule correctly imported here
    UserModule,
    DashboardModule,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
