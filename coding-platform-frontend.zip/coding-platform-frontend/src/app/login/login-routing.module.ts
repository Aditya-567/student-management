import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SignInComponent } from './sign-in/sign-in.component';
import { SignUpComponent } from './sign-up/sign-up.component';

const routes: Routes = [
  { path: 'sign-in', component: SignInComponent }, // Corrected path
  { path: 'sign-up', component: SignUpComponent }, // Corrected path
  // { path: '', redirectTo: 'sign-in', pathMatch: 'full' }, // Redirect to sign-in by default
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LoginRoutingModule {}
