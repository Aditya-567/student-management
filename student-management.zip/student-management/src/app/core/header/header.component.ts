import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent {
  @Input() isLoggedIn = false; // Receive isLoggedIn from AppComponent
  @Output() logoutEvent = new EventEmitter<void>(); // Emit logout event

  logout(): void {
    this.logoutEvent.emit(); //Notify AppComponent to update isLoggedIn
  }
}
