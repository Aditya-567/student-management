import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { StudentDetailsComponent } from './student-details/student-details.component';
import { StudentListComponent } from './student-list/student-list.component';
import { StudentService } from './student.service';

@NgModule({
  declarations: [StudentListComponent, StudentDetailsComponent],
  imports: [CommonModule, FormsModule],
  providers: [StudentService],
  exports: [StudentListComponent, StudentDetailsComponent],
})
export class StudentModule {}
