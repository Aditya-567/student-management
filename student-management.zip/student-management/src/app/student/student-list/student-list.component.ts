import { Component } from '@angular/core';
import { Student } from '../student.model';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-list',

  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css'],
})
export class StudentListComponent {
  students: Student[] = [];
  selectedStudent?: Student;

  constructor(private studentService: StudentService) {
    //Injecting StudentService
    this.students = this.studentService.getStudents();
  }

  selectStudent(student: Student): void {
    this.selectedStudent = student;
  }
}
